import csv
import hashlib
import json
import os
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from app.server import Handler, ROOT, ROUTES, read_forecast, read_actual, parse_scenario, interpret_event


class ForecastDataTest(unittest.TestCase):
    def test_natural_event_has_no_fabricated_prediction(self):
        rain = interpret_event('18 сентября дождь с 12-13', '2026-01-01')
        self.assertEqual(rain['intent']['from_date'], '2026-09-18')
        self.assertEqual((rain['intent']['from_hour'], rain['intent']['to_hour']), (12, 13))
        self.assertEqual(rain['status'], 'needs_baseline')
        self.assertEqual(rain['intent']['effect_source'], 'model_required')
        works = interpret_event('12-14 сентября дорожные работы', '2026-01-01')
        self.assertEqual(works['status'], 'needs_location')
        self.assertEqual(works['intent']['to_date_inclusive'], '2026-09-14')
        self.assertEqual(interpret_event('12-14 сентября дорожные работы на маршруте 11',
                                         '2026-01-01')['status'], 'needs_baseline')
        self.assertEqual(interpret_event('18 сентября 2025 дождь с 12-13',
                                         '2026-01-01')['status'], 'needs_historical_backtest')
        self.assertEqual(interpret_event('18 ноября 2025 дождь с 12-13',
                                         '2026-01-01')['status'], 'needs_event_model')

    def test_scenario_scope_and_ambiguous_effect(self):
        scenario = parse_scenario('Маршрут 11, 03.11.2025, с 14 до 18, ремонт, −30%',
                                  '2025-11-01')
        self.assertEqual((scenario['route'], scenario['date'], scenario['from_hour'],
                          scenario['to_hour'], scenario['factor']), (11, '2025-11-03', 14, 18, .7))
        with self.assertRaisesRegex(ValueError, 'ручной эффект'):
            parse_scenario('Маршрут 11, 03.11.2025, ремонт', '2025-11-01')
        with self.assertRaisesRegex(ValueError, 'относительные даты'):
            parse_scenario('Маршрут 11 завтра −30%', '2025-11-01')

    def test_optional_actual_keeps_missing_distinct_from_zero(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'actual.csv'
            path.write_text('route;date;hour;actual;status;available_at\n'
                            '1;2025-11-01;13;0;complete;2025-11-02T00:00:00+03:00\n'
                            '1;2025-11-01;14;20;partial;2025-11-02T00:00:00+03:00\n')
            actual = read_actual(path)
            self.assertEqual(len(actual), 2)
            self.assertEqual(actual[(1, '2025-11-01', 13)]['actual'], 0)
            self.assertNotIn((1, '2025-11-01', 12), actual)
    def test_complete_submission_and_day_month_reconciliation(self):
        forecast = read_forecast(ROOT / 'data' / 'forecast.csv')
        self.assertEqual(set(forecast), set(ROUTES))
        self.assertEqual(sum(len(x) for x in forecast.values()), 14_640)
        self.assertEqual(sum(forecast[1][('2025-11-01', h)] for h in range(24)),
                         sum(value for (day, _), value in forecast[1].items() if day == '2025-11-01'))

    def test_duplicate_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'bad.csv'
            path.write_text('route;date;hour;prediction\n1;2025-11-01;0;5\n1;2025-11-01;0;6\n')
            with self.assertRaisesRegex(ValueError, 'Duplicate'):
                read_forecast(path)

    def test_nonfinite_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'bad.csv'
            path.write_text('route;date;hour;prediction\n1;2025-11-01;0;nan\n')
            with self.assertRaisesRegex(ValueError, 'finite'):
                read_forecast(path)


class ApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        salt = os.urandom(16)
        Handler.auth = {'username': 'tester', 'salt': salt.hex(),
                        'password_hash': hashlib.pbkdf2_hmac('sha256', b'test-password-123', salt, 260_000).hex(),
                        'session_key': os.urandom(32).hex()}
        Handler.forecast = read_forecast(ROOT / 'data' / 'forecast.csv')
        Handler.geometry = json.loads((ROOT / 'data' / 'routes.json').read_text())
        Handler.quality = json.loads((ROOT / 'data' / 'quality.json').read_text())
        Handler.actual = {}
        Handler.events = []
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.base = f'http://127.0.0.1:{cls.server.server_port}'

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def test_login_forecast_export(self):
        with urlopen(self.base + '/api/me') as response:
            self.assertFalse(json.load(response)['authenticated'])
        with self.assertRaises(HTTPError) as denied:
            urlopen(self.base + '/api/forecast?route=1')
        self.assertEqual(denied.exception.code, 401)
        payload = json.dumps({'username': 'tester', 'password': 'test-password-123'}).encode()
        with urlopen(Request(self.base + '/api/login', payload,
                             {'Content-Type': 'application/json'})) as response:
            cookie = response.headers['Set-Cookie'].split(';')[0]
        headers = {'Cookie': cookie}
        def get(path):
            return urlopen(Request(self.base + path, headers=headers))
        with get('/api/me') as response:
            me = json.load(response)
            self.assertTrue(me['authenticated'])
            self.assertEqual(me['username'], 'tester')
        with get('/api/forecast?route=1&date=2025-11-01&period=day') as response:
            day = json.load(response)
        self.assertEqual(len(day['records']), 24)
        self.assertEqual(day['granularity'], 'route')
        with get('/api/forecast?route=1&date=2025-11-01&period=month') as response:
            month = json.load(response)
        self.assertEqual(sum(row['prediction'] for row in day['records']), month['records'][0]['prediction'])
        with get('/api/forecast?route=1&date=2025-11-01&period=week') as response:
            week = json.load(response)
        self.assertEqual(len(week['records']), 7)
        self.assertEqual(week['records'][0]['prediction'], month['records'][0]['prediction'])
        with get('/api/quality') as response:
            quality = json.load(response)
        self.assertEqual(next(x for x in quality['routes'] if x['route'] == 5)['status'], 'no_history')
        with get('/api/actual?route=1&date=2025-11-01') as response:
            self.assertFalse(json.load(response)['available'])
        scenario_payload = json.dumps({'text': 'Маршрут 11, 03.11.2025, с 14 до 18, ремонт, −30%',
                                       'date': '2025-11-01'}).encode()
        with urlopen(Request(self.base + '/api/scenario/preview', scenario_payload,
                             {**headers, 'Content-Type': 'application/json'})) as response:
            preview = json.load(response)
        self.assertEqual(len(preview['records']), 24)
        self.assertEqual(preview['records'][13]['base'], preview['records'][13]['scenario'])
        self.assertLessEqual(preview['records'][14]['scenario'], preview['records'][14]['base'])
        event_payload = json.dumps({'text': '18 сентября дождь с 12-13',
                                    'date': '2026-01-01'}).encode()
        with urlopen(Request(self.base + '/api/scenario/interpret', event_payload,
                             {**headers, 'Content-Type': 'application/json'})) as response:
            event = json.load(response)
        self.assertEqual(event['status'], 'needs_baseline')
        self.assertNotIn('records', event)
        with get('/api/export?route=1&date=2025-11-01&period=day') as response:
            rows = list(csv.DictReader(response.read().decode('utf-8-sig').splitlines(), delimiter=';'))
        self.assertEqual(len(rows), 24)
        self.assertEqual(int(rows[0]['prediction']), day['records'][0]['prediction'])
        with urlopen(Request(self.base + '/api/logout', b'', headers)) as response:
            self.assertIn('Max-Age=0', response.headers['Set-Cookie'])


if __name__ == '__main__':
    unittest.main()
