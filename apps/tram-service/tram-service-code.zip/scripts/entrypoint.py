"""Stage the bind-mounted 0600 credential into tmpfs, then drop privileges."""
import os
import sys

source = os.environ.get('AUTH_FILE', '/run/secrets/auth.json')
target = '/tmp/tram-auth.json'
fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with open(source, 'rb') as secret, os.fdopen(fd, 'wb') as staged:
    while chunk := secret.read(65536):
        staged.write(chunk)
os.chown(target, 10001, 10001)
os.chmod(target, 0o600)
os.environ['AUTH_FILE'] = target
os.setgroups([])
os.setgid(10001)
os.setuid(10001)
os.execv(sys.executable, [sys.executable, '-m', 'app.server'])
