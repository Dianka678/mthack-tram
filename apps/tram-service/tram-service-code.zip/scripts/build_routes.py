"""Extract display-only route geometry from the supplied GTFS workbook."""
import json
import sys
from collections import defaultdict
from pathlib import Path

from openpyxl import load_workbook

FORECAST_ROUTES = {1, 5, 7, 11, 12, 17, 25, 26, 28, 50}


def build(source, target):
    book = load_workbook(source, read_only=True, data_only=True)
    rows = book['Порядок_с_координатами'].iter_rows(values_only=True)
    columns = next(rows)
    groups = defaultdict(list)
    for values in rows:
        item = dict(zip(columns, values))
        try:
            route = int(item['route_short_name'])
            lat, lon = float(item['stop_lat']), float(item['stop_lon'])
            sequence = int(item['stop_sequence'])
        except (TypeError, ValueError):
            continue
        if route not in FORECAST_ROUTES:
            continue
        if not (55.0 < lat < 56.5 and 36.0 < lon < 39.0):
            continue
        key = (route, str(item['trip_id']), str(item['direction_id']))
        groups[key].append((sequence, str(item['stop_id']), str(item['stop_name']), lat, lon))
    result = {}
    for (route, trip, direction), stops in groups.items():
        stops.sort()
        record = {'trip': trip, 'direction': direction, 'stops': [
            {'id': stop_id, 'name': name, 'lat': lat, 'lon': lon}
            for _, stop_id, name, lat, lon in stops
        ]}
        # One representative variant per route, prefer the most complete.
        if len(stops) > len(result.get(str(route), {}).get('stops', [])):
            result[str(route)] = record
    Path(target).write_text(json.dumps(result, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    print('routes with geometry:', ', '.join(sorted(result, key=int)))


if __name__ == '__main__':
    build(sys.argv[1], sys.argv[2])
