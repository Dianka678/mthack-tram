"""Create an independent credentials file without storing a password in Git."""
import getpass
import hashlib
import json
import os
from pathlib import Path

target = Path(__file__).resolve().parents[1] / 'secrets' / 'auth.json'
target.parent.mkdir(exist_ok=True)
if target.exists():
    if target.is_dir():
        raise SystemExit(f'{target} is a directory, not a credentials file. Stop Docker Compose, rename the directory, then rerun this script')
    raise SystemExit(f'{target} already exists; remove it deliberately to rotate credentials')
username = input('Login: ').strip()
password = getpass.getpass('Password: ')
if not username or len(password) < 12:
    raise SystemExit('Login must be nonempty and password at least 12 characters')
salt = os.urandom(16)
record = {
    'username': username,
    'salt': salt.hex(),
    'password_hash': hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 260_000).hex(),
    'session_key': os.urandom(32).hex(),
}
fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
with os.fdopen(fd, 'w', encoding='utf-8') as out:
    json.dump(record, out)
print(f'Created {target}; keep it out of version control')
