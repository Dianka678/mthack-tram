"""Aggregate label gaps for an honest, route-level data quality screen.

Missing label rows are only candidates for investigation. No cause is inferred.
"""
import csv
import json
import statistics
import sys
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

ROUTES = (1, 5, 7, 11, 12, 17, 25, 26, 28, 50)
START, END = date(2025, 1, 1), date(2025, 10, 31)


def build(paths, target):
    labels = {}
    by_profile = defaultdict(list)
    for path in paths:
        with open(path, newline='', encoding='utf-8-sig') as stream:
            reader = csv.DictReader(stream, delimiter=';')
            if reader.fieldnames != ['route', 'date', 'hour', 'boardings']:
                raise ValueError('Expected route;date;hour;boardings')
            for row in reader:
                route, day, hour, value = int(row['route']), date.fromisoformat(row['date']), int(row['hour']), int(row['boardings'])
                if not START <= day <= END:
                    continue
                key = (route, day, hour)
                if key in labels:
                    raise ValueError(f'Duplicate label {key}')
                labels[key] = value
                by_profile[(route, day.weekday(), hour)].append((day, value))
    summary, gaps = [], []
    days = (END - START).days + 1
    for route in ROUTES:
        if route == 5:
            summary.append({'route': route, 'status': 'no_history', 'observed_hours': 0,
                            'missing_daytime_hours': None, 'total_daytime_hours': days * 17})
            continue
        observed = sum(1 for key in labels if key[0] == route)
        missing = 0
        cursor = START
        while cursor <= END:
            run = []
            for hour in range(6, 23):
                if (route, cursor, hour) not in labels:
                    missing += 1
                    run.append(hour)
                else:
                    if len(run) >= 3:
                        gaps.append(gap_info(route, cursor, run, by_profile))
                    run = []
            if len(run) >= 3:
                gaps.append(gap_info(route, cursor, run, by_profile))
            cursor += timedelta(days=1)
        summary.append({'route': route, 'status': 'history', 'observed_hours': observed,
                        'missing_daytime_hours': missing, 'total_daytime_hours': days * 17})
    gaps.sort(key=lambda g: (-g['hours'], g['date'], g['route']))
    payload = {'period': {'from': START.isoformat(), 'to': END.isoformat()},
               'definition': 'Отсутствует строка метки в часы 06:00–22:59; это не доказанный сбой и не подтверждённое расписание',
               'method': 'Иллюстративная медиана того же маршрута, дня недели и часа за предыдущие 56 дней; не применяется к конкурсному прогнозу',
               'routes': summary, 'gaps': gaps[:80]}
    Path(target).write_text(json.dumps(payload, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    print(f'Wrote {len(payload["gaps"])} candidate intervals')


def gap_info(route, day, hours, profiles):
    estimates = []
    for hour in hours:
        history = [v for past, v in profiles[(route, day.weekday(), hour)]
                   if day - timedelta(days=56) <= past < day]
        if history:
            estimates.append(statistics.median(history))
    return {'route': route, 'date': day.isoformat(), 'start_hour': min(hours),
            'end_hour': max(hours), 'hours': len(hours),
            'analog_estimate': round(sum(estimates)) if len(estimates) == len(hours) else None,
            'analog_hours_available': len(estimates)}


if __name__ == '__main__':
    build(sys.argv[1:-1], sys.argv[-1])
